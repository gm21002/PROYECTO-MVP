<?php
// index.php
header("Location: Vistas/login.php");
exit;
